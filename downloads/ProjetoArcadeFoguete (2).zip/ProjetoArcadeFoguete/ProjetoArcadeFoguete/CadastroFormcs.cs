﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace ProjetoArcadeFoguete
{
    public partial class CadastroFormcs : Form
    {
        private string connectionString = "Data Source=game_scores.db;Version=3;";
        private DatabaseHelper dbHelper; // Instância para gerenciar o banco de dados

        public CadastroFormcs()
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper(); // Garante que o banco de dados seja criado
            CriarTabelaUsuarios(); // Garante que a tabela Users exista
        }

        private void btn_cadastrar_Click(object sender, EventArgs e)
        {
            string GamerTag = txtGamerTag.Text; // TextBox para GamerTag
            string senha = txtSenha.Text; // TextBox para Senha

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO Users (GamerTag, senha) VALUES (@GamerTag, @senha)";

                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@GamerTag", GamerTag);
                    command.Parameters.AddWithValue("@senha", senha);

                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Usuário cadastrado com sucesso!");
                        this.Hide(); // Esconde a tela de cadastro
                        LoginForm loginForm = new LoginForm(); // Abre a tela de login
                        loginForm.Show();
                    }
                    catch (SQLiteException ex)
                    {
                        MessageBox.Show("Erro ao cadastrar usuário: " + ex.Message);
                    }
                }
            }
        }

        private void CriarTabelaUsuarios()
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string createTableQuery = @"CREATE TABLE IF NOT EXISTS Users (
                                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                            GamerTag TEXT NOT NULL,
                                            senha TEXT NOT NULL)";
                using (var command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        private void btn_voltar_Click(object sender, EventArgs e)
        {
            // Crie uma nova instância da tela de login
            LoginForm loginForm = new LoginForm();

            // Esconde a tela de cadastro
            this.Hide();

            // Mostra a tela de login
            loginForm.Show();
        }
    }
}
