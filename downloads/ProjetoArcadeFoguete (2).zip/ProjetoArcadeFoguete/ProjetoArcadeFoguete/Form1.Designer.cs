﻿namespace ProjetoArcadeFoguete
{
    partial class Game
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            bg = new PictureBox();
            base_lancamento = new PictureBox();
            foguete = new PictureBox();
            btn_launch = new PictureBox();
            gasosa = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            lbl_gasosa = new Label();
            lbl_distancia = new Label();
            lbl_score = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            lbl_over = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            btn_restart = new Button();
            ((System.ComponentModel.ISupportInitialize)bg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)base_lancamento).BeginInit();
            ((System.ComponentModel.ISupportInitialize)foguete).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btn_launch).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gasosa).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // bg
            // 
            bg.Image = Properties.Resources.bg_img;
            bg.Location = new Point(-1, 331);
            bg.Name = "bg";
            bg.Size = new Size(435, 129);
            bg.SizeMode = PictureBoxSizeMode.StretchImage;
            bg.TabIndex = 0;
            bg.TabStop = false;
            // 
            // base_lancamento
            // 
            base_lancamento.Image = Properties.Resources.launch_pad_img;
            base_lancamento.Location = new Point(159, 410);
            base_lancamento.Name = "base_lancamento";
            base_lancamento.Size = new Size(122, 50);
            base_lancamento.TabIndex = 1;
            base_lancamento.TabStop = false;
            base_lancamento.Click += base_lancamento_Click;
            // 
            // foguete
            // 
            foguete.BackColor = Color.Transparent;
            foguete.Image = Properties.Resources.foguete_img;
            foguete.Location = new Point(204, 379);
            foguete.Name = "foguete";
            foguete.Size = new Size(28, 49);
            foguete.SizeMode = PictureBoxSizeMode.AutoSize;
            foguete.TabIndex = 2;
            foguete.TabStop = false;
            // 
            // btn_launch
            // 
            btn_launch.Image = Properties.Resources.launch_btn_img;
            btn_launch.Location = new Point(159, 181);
            btn_launch.Name = "btn_launch";
            btn_launch.Size = new Size(122, 44);
            btn_launch.SizeMode = PictureBoxSizeMode.AutoSize;
            btn_launch.TabIndex = 3;
            btn_launch.TabStop = false;
            btn_launch.Click += btn_launch_Click;
            // 
            // gasosa
            // 
            gasosa.Image = Properties.Resources.fuel_img;
            gasosa.Location = new Point(71, 331);
            gasosa.Name = "gasosa";
            gasosa.Size = new Size(20, 36);
            gasosa.SizeMode = PictureBoxSizeMode.AutoSize;
            gasosa.TabIndex = 4;
            gasosa.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.rock_img;
            pictureBox2.Location = new Point(357, 342);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(31, 36);
            pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            pictureBox2.Tag = "rocha";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.rock_img;
            pictureBox3.Location = new Point(128, 342);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(31, 36);
            pictureBox3.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            pictureBox3.Tag = "rocha";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.rock_img;
            pictureBox4.Location = new Point(42, 392);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(31, 36);
            pictureBox4.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox4.TabIndex = 7;
            pictureBox4.TabStop = false;
            pictureBox4.Tag = "rocha";
            // 
            // lbl_gasosa
            // 
            lbl_gasosa.AutoSize = true;
            lbl_gasosa.Font = new Font("Space Age", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_gasosa.ForeColor = Color.FromArgb(255, 255, 128);
            lbl_gasosa.Location = new Point(-1, 9);
            lbl_gasosa.Name = "lbl_gasosa";
            lbl_gasosa.Size = new Size(174, 17);
            lbl_gasosa.TabIndex = 8;
            lbl_gasosa.Text = "GASOSA: 0/L";
            // 
            // lbl_distancia
            // 
            lbl_distancia.AutoSize = true;
            lbl_distancia.Font = new Font("Space Age", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_distancia.ForeColor = Color.FromArgb(255, 255, 128);
            lbl_distancia.Location = new Point(-1, 42);
            lbl_distancia.Name = "lbl_distancia";
            lbl_distancia.Size = new Size(221, 17);
            lbl_distancia.TabIndex = 9;
            lbl_distancia.Text = "DISTÂNCIA: 0/KM";
            // 
            // lbl_score
            // 
            lbl_score.AutoSize = true;
            lbl_score.Font = new Font("Space Age", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_score.ForeColor = Color.FromArgb(255, 255, 128);
            lbl_score.Location = new Point(-1, 79);
            lbl_score.Name = "lbl_score";
            lbl_score.Size = new Size(201, 17);
            lbl_score.TabIndex = 10;
            lbl_score.Text = "PONTUAÇÃO: 0";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(42, 171);
            label1.Name = "label1";
            label1.Size = new Size(15, 23);
            label1.TabIndex = 11;
            label1.Tag = "stars";
            label1.Text = "*";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(91, 214);
            label2.Name = "label2";
            label2.Size = new Size(15, 23);
            label2.TabIndex = 12;
            label2.Tag = "stars";
            label2.Text = "*";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlLightLight;
            label3.Location = new Point(21, 259);
            label3.Name = "label3";
            label3.Size = new Size(15, 23);
            label3.TabIndex = 13;
            label3.Tag = "stars";
            label3.Text = "*";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlLightLight;
            label4.Location = new Point(316, 103);
            label4.Name = "label4";
            label4.Size = new Size(15, 23);
            label4.TabIndex = 14;
            label4.Tag = "stars";
            label4.Text = "*";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ControlLightLight;
            label5.Location = new Point(298, 33);
            label5.Name = "label5";
            label5.Size = new Size(15, 23);
            label5.TabIndex = 15;
            label5.Tag = "stars";
            label5.Text = "*";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ControlLightLight;
            label6.Location = new Point(329, 171);
            label6.Name = "label6";
            label6.Size = new Size(15, 23);
            label6.TabIndex = 16;
            label6.Tag = "stars";
            label6.Text = "*";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlLightLight;
            label7.Location = new Point(128, 299);
            label7.Name = "label7";
            label7.Size = new Size(15, 23);
            label7.TabIndex = 17;
            label7.Tag = "stars";
            label7.Text = "*";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.ControlLightLight;
            label8.Location = new Point(261, 299);
            label8.Name = "label8";
            label8.Size = new Size(15, 23);
            label8.TabIndex = 18;
            label8.Tag = "stars";
            label8.Text = "*";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = SystemColors.ControlLightLight;
            label9.Location = new Point(204, 291);
            label9.Name = "label9";
            label9.Size = new Size(15, 23);
            label9.TabIndex = 19;
            label9.Tag = "stars";
            label9.Text = "*";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = SystemColors.ControlLightLight;
            label10.Location = new Point(386, 143);
            label10.Name = "label10";
            label10.Size = new Size(15, 23);
            label10.TabIndex = 20;
            label10.Tag = "stars";
            label10.Text = "*";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = SystemColors.ControlLightLight;
            label11.Location = new Point(298, 259);
            label11.Name = "label11";
            label11.Size = new Size(15, 23);
            label11.TabIndex = 21;
            label11.Tag = "stars";
            label11.Text = "*";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = SystemColors.ControlLightLight;
            label12.Location = new Point(357, 267);
            label12.Name = "label12";
            label12.Size = new Size(15, 23);
            label12.TabIndex = 22;
            label12.Tag = "stars";
            label12.Text = "*";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = SystemColors.ControlLightLight;
            label13.Location = new Point(329, 305);
            label13.Name = "label13";
            label13.Size = new Size(15, 23);
            label13.TabIndex = 23;
            label13.Tag = "stars";
            label13.Text = "*";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = SystemColors.ControlLightLight;
            label14.Location = new Point(204, 122);
            label14.Name = "label14";
            label14.Size = new Size(15, 23);
            label14.TabIndex = 24;
            label14.Tag = "stars";
            label14.Text = "*";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = SystemColors.ControlLightLight;
            label15.Location = new Point(115, 122);
            label15.Name = "label15";
            label15.Size = new Size(15, 23);
            label15.TabIndex = 25;
            label15.Tag = "stars";
            label15.Text = "*";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = SystemColors.ControlLightLight;
            label16.Location = new Point(217, 42);
            label16.Name = "label16";
            label16.Size = new Size(15, 23);
            label16.TabIndex = 26;
            label16.Tag = "stars";
            label16.Text = "*";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = SystemColors.ControlLightLight;
            label17.Location = new Point(170, 241);
            label17.Name = "label17";
            label17.Size = new Size(15, 23);
            label17.TabIndex = 27;
            label17.Tag = "stars";
            label17.Text = "*";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.ForeColor = SystemColors.ControlLightLight;
            label18.Location = new Point(58, 23);
            label18.Name = "label18";
            label18.Size = new Size(15, 23);
            label18.TabIndex = 28;
            label18.Tag = "stars";
            label18.Text = "*";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.ForeColor = SystemColors.ControlLightLight;
            label19.Location = new Point(115, 56);
            label19.Name = "label19";
            label19.Size = new Size(15, 23);
            label19.TabIndex = 29;
            label19.Tag = "stars";
            label19.Text = "*";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.ForeColor = SystemColors.ControlLightLight;
            label20.Location = new Point(386, 33);
            label20.Name = "label20";
            label20.Size = new Size(15, 23);
            label20.TabIndex = 30;
            label20.Tag = "stars";
            label20.Text = "*";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.ForeColor = SystemColors.ControlLightLight;
            label21.Location = new Point(21, 103);
            label21.Name = "label21";
            label21.Size = new Size(15, 23);
            label21.TabIndex = 31;
            label21.Tag = "stars";
            label21.Text = "*";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Bahnschrift Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label22.ForeColor = SystemColors.ControlLightLight;
            label22.Location = new Point(234, 243);
            label22.Name = "label22";
            label22.Size = new Size(15, 23);
            label22.TabIndex = 32;
            label22.Tag = "stars";
            label22.Text = "*";
            // 
            // lbl_over
            // 
            lbl_over.AutoSize = true;
            lbl_over.Font = new Font("Space Age", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_over.ForeColor = Color.FromArgb(255, 255, 128);
            lbl_over.Location = new Point(137, 149);
            lbl_over.Name = "lbl_over";
            lbl_over.Size = new Size(161, 17);
            lbl_over.TabIndex = 33;
            lbl_over.Text = "GAME OVER";
            // 
            // timer1
            // 
            timer1.Interval = 15;
            timer1.Tick += timer1_Tick;
            // 
            // btn_restart
            // 
            btn_restart.BackColor = Color.FromArgb(255, 255, 128);
            btn_restart.Font = new Font("Space Age", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_restart.Location = new Point(148, 241);
            btn_restart.Name = "btn_restart";
            btn_restart.Size = new Size(144, 41);
            btn_restart.TabIndex = 34;
            btn_restart.Text = "RESTART";
            btn_restart.UseVisualStyleBackColor = false;
            btn_restart.Click += btn_restart_Click;
            // 
            // Game
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(434, 461);
            Controls.Add(btn_restart);
            Controls.Add(lbl_over);
            Controls.Add(lbl_score);
            Controls.Add(lbl_distancia);
            Controls.Add(lbl_gasosa);
            Controls.Add(btn_launch);
            Controls.Add(base_lancamento);
            Controls.Add(foguete);
            Controls.Add(bg);
            Controls.Add(label18);
            Controls.Add(label19);
            Controls.Add(label21);
            Controls.Add(label15);
            Controls.Add(label1);
            Controls.Add(label14);
            Controls.Add(label16);
            Controls.Add(label5);
            Controls.Add(label20);
            Controls.Add(label4);
            Controls.Add(label10);
            Controls.Add(label6);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label11);
            Controls.Add(label8);
            Controls.Add(label22);
            Controls.Add(label9);
            Controls.Add(label17);
            Controls.Add(label7);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox3);
            Controls.Add(gasosa);
            Controls.Add(pictureBox4);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Game";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Game";
            Load += Game_Load;
            KeyDown += Game_KeyDown;
            KeyUp += Game_KeyUp;
            ((System.ComponentModel.ISupportInitialize)bg).EndInit();
            ((System.ComponentModel.ISupportInitialize)base_lancamento).EndInit();
            ((System.ComponentModel.ISupportInitialize)foguete).EndInit();
            ((System.ComponentModel.ISupportInitialize)btn_launch).EndInit();
            ((System.ComponentModel.ISupportInitialize)gasosa).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox bg;
        private PictureBox base_lancamento;
        private PictureBox foguete;
        private PictureBox btn_launch;
        private PictureBox gasosa;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label lbl_gasosa;
        private Label lbl_distancia;
        private Label lbl_score;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label lbl_over;
        private System.Windows.Forms.Timer timer1;
        private Button btn_restart;
    }
}
