﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoArcadeFoguete
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            // Cria uma nova instância do jogo e exibe
            Game gameForm = new Game();
            this.Hide(); // Esconde o MenuForm
            gameForm.Show();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            // Exibe a tela de login
            LoginForm loginForm = new LoginForm();
            this.Hide(); // Esconde o MenuForm
            loginForm.Show();
        }
    }
}
