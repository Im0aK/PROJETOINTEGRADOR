﻿using System;
using System.Data.SQLite;
using System.IO;

namespace ProjetoArcadeFoguete
{
    public class DatabaseHelper
    {
        private string connectionString = "Data Source=game_scores.db;Version=3;";

        public DatabaseHelper()
        {
            CriarBancoDeDados(); // Garante a criação do banco e das tabelas ao inicializar
        }

        private void CriarBancoDeDados()
        {
            // Verifica se o arquivo do banco de dados já existe
            if (!File.Exists("game_scores.db"))
            {
                SQLiteConnection.CreateFile("game_scores.db");
                Console.WriteLine("Banco de dados criado com sucesso!");
            }

            // Conexão e criação das tabelas caso elas não existam
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                CriarTabelaScores(connection);
                CriarTabelaUsers(connection);

                Console.WriteLine("Tabelas Scores e Users criadas com sucesso, se ainda não existiam.");
            }
        }

        // Método para criação da tabela Scores
        private void CriarTabelaScores(SQLiteConnection connection)
        {
            string createScoresTable = @"
                CREATE TABLE IF NOT EXISTS Scores (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    GamerTag TEXT NOT NULL,
                    Score INTEGER NOT NULL,
                    Distance INTEGER NOT NULL,
                    Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );";

            using (var command = new SQLiteCommand(createScoresTable, connection))
            {
                command.ExecuteNonQuery();
            }
        }

        // Método para criação da tabela Users
        private void CriarTabelaUsers(SQLiteConnection connection)
        {
            string createUsersTable = @"
                    CREATE TABLE IF NOT EXISTS Users (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    GamerTag TEXT NOT NULL UNIQUE,
                    Senha TEXT NOT NULL
                );";

            using (var command = new SQLiteCommand(createUsersTable, connection))
            {
                command.ExecuteNonQuery();
            }
        }
    }
}
