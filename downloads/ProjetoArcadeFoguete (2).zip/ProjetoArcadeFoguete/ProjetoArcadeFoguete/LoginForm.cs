﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;

namespace ProjetoArcadeFoguete
{
    public partial class LoginForm : Form
    {
        private string connectionString = "Data Source=game_scores.db;Version=3;";
        private DatabaseHelper dbHelper;

        public LoginForm()
        {
            InitializeComponent();
            CriarTabelaUsuarios(); // Garante que a tabela Users exista
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string query = "SELECT COUNT(1) FROM Users WHERE GamerTag = @GamerTag AND senha = @senha";

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@GamerTag", txtGamerTagLogin.Text);
                    command.Parameters.AddWithValue("@senha", txtSenhaLogin.Text); // Corrige para usar @senha

                    var result = command.ExecuteScalar();
                    int userExists = (result != null) ? Convert.ToInt32(result) : 0;

                    if (userExists == 1)
                    {
                        // Login bem-sucedido
                        MenuForm menuForm = new MenuForm();
                        this.Hide();
                        menuForm.Show();
                    }
                    else
                    {
                        MessageBox.Show("Login falhou. Verifique suas credenciais.");
                    }
                }
            }
        }

        private void CriarTabelaUsuarios()
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string createTableQuery = @"CREATE TABLE IF NOT EXISTS Users (
                                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                            GamerTag TEXT NOT NULL,
                                            senha TEXT NOT NULL)";
                using (var command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        private void btn_cadastrese_Click(object sender, EventArgs e)
        {
            CadastroFormcs cadastroForm = new CadastroFormcs();
            cadastroForm.Show();
            this.Hide();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Você tem certeza que deseja sair?", "Sair", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
