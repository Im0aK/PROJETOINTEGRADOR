﻿namespace ProjetoArcadeFoguete
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
            btn_start = new Button();
            btn_exit = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btn_start
            // 
            btn_start.BackColor = Color.FromArgb(255, 255, 128);
            btn_start.Font = new Font("Space Age", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_start.Location = new Point(106, 132);
            btn_start.Name = "btn_start";
            btn_start.Size = new Size(115, 48);
            btn_start.TabIndex = 0;
            btn_start.Text = "INICIAR ";
            btn_start.UseVisualStyleBackColor = false;
            btn_start.Click += btn_start_Click;
            // 
            // btn_exit
            // 
            btn_exit.BackColor = Color.FromArgb(255, 255, 128);
            btn_exit.Font = new Font("Space Age", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_exit.Location = new Point(276, 132);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(115, 48);
            btn_exit.TabIndex = 1;
            btn_exit.Text = "SAIR";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += btn_exit_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-1, -2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(500, 307);
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // MenuForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(499, 302);
            Controls.Add(btn_exit);
            Controls.Add(btn_start);
            Controls.Add(pictureBox1);
            Name = "MenuForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MenuForm";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btn_start;
        private Button btn_exit;
        private Label label5;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private PictureBox pictureBox1;
    }
}