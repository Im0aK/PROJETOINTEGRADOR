using System.Security.Cryptography;
using System.Data.SQLite;


namespace ProjetoArcadeFoguete
{
    public partial class Game : Form
    {
        public Game()
        {
            InitializeComponent();
            DatabaseHelper db = new DatabaseHelper(); // Garante que o banco de dados seja criado

            lbl_over.Hide();
            lbl_over.Hide();

            // Registrar os eventos de teclado
            this.KeyDown += new KeyEventHandler(Game_KeyDown);
            this.KeyUp += new KeyEventHandler(Game_KeyUp);
        }


        bool direita, esquerda;
        bool pacima, pabaixo;
        Random rnd = new Random();
        int x, distancia, y, fq = 1000, score;


        private string connectionString = "Data Source=game_scores.db;Version=3;";



        private void SaveScore(string GamerTag, int score, int distance)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string insertQuery = "INSERT INTO Scores (GamerTag, Score, Distance) VALUES (@GamerTag, @Score, @Distance)";

                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@GamerTag", GamerTag);
                    command.Parameters.AddWithValue("@Score", score);
                    command.Parameters.AddWithValue("@Distance", distance);
                    command.ExecuteNonQuery();
                }
            }
        }

        private void LoadScores()
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Scores ORDER BY Score DESC";

                using (var command = new SQLiteCommand(selectQuery, connection))
                {
                    using (SQLiteDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string GamerTag = reader["GamerTag"].ToString();
                            int score = Convert.ToInt32(reader["Score"]);
                            int distance = Convert.ToInt32(reader["Distance"]);

                            // Aqui voc� pode adicionar o c�digo para exibir as pontua��es em algum controle, como um ListBox ou DataGridView
                            Console.WriteLine($"Jogador: {GamerTag}, Pontua��o: {score}, Dist�ncia: {distance}");
                        }
                    }
                }
            }
        }

        void logica_game()
        {
            foreach (Control j in this.Controls) // Percorre todos os controles no formul�rio
            {
                if (j is PictureBox && j.Tag == "rocha") // Verifica se o controle � uma rocha
                {
                    if (foguete.Bounds.IntersectsWith(j.Bounds)) // Verifica colis�o com o foguete
                    {
                        timer1.Stop(); // Para o jogo
                        foguete.Image = Properties.Resources.Explosion_img; // Imagem de explos�o
                        lbl_over.Show(); // Mostra a mensagem de Game Over
                        btn_restart.Show(); // Mostra o bot�o de reiniciar
                    }
                }
            }
        }





        void abastecer_gasosa()
        {
            if (gasosa.Top > 400)
            {
                y = rnd.Next(0, 300);
                gasosa.Location = new Point(y, 0);
            }

            if (foguete.Bounds.IntersectsWith(gasosa.Bounds))
            {
                gasosa.Top = -300;
                y = rnd.Next(0, 300);
                gasosa.Location = new Point(x, 0);

                // Verifica se a gasosa n�o ultrapassa 1000
                if (fq < 1000)
                {
                    fq += 100;

                    // Garante que fq n�o seja maior que 1000
                    if (fq > 1000)
                    {
                        fq = 1000;
                    }

                    lbl_gasosa.Text = "gasosa : " + fq + "/L";
                }
            }

            if (fq > 0)
            {
                fq -= 1;
                lbl_gasosa.Text = "gasosa : " + fq + "/L";
            }

            // Verifica se o combust�vel acabou
            if (fq < 1)
            {
                timer1.Stop();         // Para o jogo

                // Ajusta a imagem de explos�o e define uma posi��o fixa para ela
                foguete.Image = Properties.Resources.Explosion_img; // Mostra a imagem de explos�o
                foguete.Location = new Point(150, 200); // Define uma posi��o fixa para a explos�o (ajuste conforme necess�rio)

                lbl_over.Text = "VOC� � BURRO POR ACASO?"; // Define o texto da mensagem de Game Over
                lbl_over.Location = new Point(35, 350); // Define uma posi��o fixa para a mensagem (ajuste conforme necess�rio)
                lbl_over.Show();       // Mostra a mensagem de Game Over

                btn_restart.Show();    // Mostra o bot�o de reiniciar
            }

            gasosa.Top += 3;
        }


        // Declare uma vari�vel para a velocidade das rochas
        int velocidadeRochas = 4; // Velocidade inicial das rochas
        const int aumentoDistancia = 1000; // Dist�ncia para aumentar a velocidade
        int distanciaAnterior = 0; // Para armazenar a dist�ncia anterior

        void Rochas()
        {
            foreach (Control j in this.Controls)
            {
                if (j is PictureBox && j.Tag == "rocha")
                {
                    j.Top += velocidadeRochas; // Move as rochas pela velocidade atual
                    if (j.Top > 500)
                    {
                        x = rnd.Next(0, 500);
                        j.Location = new Point(x, 0);
                    }
                }
            }

            // Verifica se a dist�ncia atingiu um m�ltiplo de 1000 km
            if (distancia >= distanciaAnterior + aumentoDistancia)
            {
                // Aumenta a velocidade das rochas
                velocidadeRochas += 1; // Aumente conforme desejado
                distanciaAnterior += aumentoDistancia; // Atualiza a dist�ncia anterior
            }
        }


        void mover_teclas()
        {
            if (direita == true) // Se a tecla Direita estiver pressionada
            {
                if (foguete.Left + foguete.Width < this.ClientSize.Width) // Limita a movimenta��o para n�o sair da tela
                {
                    foguete.Left += 4; // Move o foguete para a direita
                }
            }

            if (esquerda == true) // Se a tecla Esquerda estiver pressionada
            {
                if (foguete.Left > 0) // Limita a movimenta��o para n�o sair da tela
                {
                    foguete.Left -= 4; // Move o foguete para a esquerda
                }
            }

            if (pacima == true) // Se a tecla Cima estiver pressionada
            {
                if (foguete.Top > 0) // Limita a movimenta��o para n�o sair da tela
                {
                    foguete.Top -= 8; // Move o foguete para cima
                }
            }

            if (pabaixo == true) // Se a tecla Baixo estiver pressionada
            {
                if (foguete.Top + foguete.Height < this.ClientSize.Height) // Limita a movimenta��o para n�o sair da tela
                {
                    foguete.Top += 5; // Move o foguete para baixo
                }
            }
        }

        void Base_lancamento()
        {
            if (foguete.Top <= 800)
            {
                foguete.Top -= 1;
                base_lancamento.Top += 1;
                bg.Top += 1;
                if (foguete.Top <= 250)
                {
                    foguete.Top = 250;
                }
            }
        }


        void estrela()
        {
            foreach (Control j in this.Controls)
            {
                if (j is Label && j.Tag == "stars")
                {
                    j.SendToBack();
                    j.Top += 10;
                    if (j.Top > 400)
                    {
                        j.Top = 0;
                        distancia += 2;
                        lbl_distancia.Text = "Distancia : " + distancia + "/KM";
                        score += 1;
                        lbl_score.Text = "Score :  " + score;
                    }
                }
            }
        }



        private void Game_Load(object sender, EventArgs e)
        {
            btn_restart.Hide(); // Esconde o bot�o de reiniciar no in�cio
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            Base_lancamento(); // Atualiza a base de lan�amento
            estrela(); // Atualiza as estrelas
            mover_teclas(); // Atualiza a movimenta��o do foguete
            Rochas(); // Atualiza as rochas
            abastecer_gasosa(); // Atualiza a gasosa
            logica_game(); // Chama a l�gica de colis�o e outras verifica��es
        }




        private void base_lancamento_Click(object sender, EventArgs e)
        {
            ////////////////////////
        }

        private void btn_launch_Click(object sender, EventArgs e)
        {
            base_lancamento.Visible = true; // Garante que a base de lan�amento esteja vis�vel
            bg.Visible = true; // Garante que o fundo esteja vis�vel

            // Define a posi��o inicial do foguete na base de lan�amento
            foguete.Location = new Point(200, 400); // Posi��o inicial do foguete

            // Inicia o timer para come�ar o jogo
            timer1.Start();
            btn_launch.Hide(); // Esconde o bot�o de lan�amento

        }

        private void Game_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right)
            {
                direita = true;
            }
            if (e.KeyCode == Keys.Left)
            {
                esquerda = true;
            }
            if (e.KeyCode == Keys.Up)
            {
                pacima = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                pabaixo = true;
            }
        }

        private void Game_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right)
            {
                direita = false;
            }
            if (e.KeyCode == Keys.Left)
            {
                esquerda = false;
            }
            if (e.KeyCode == Keys.Up)
            {
                pacima = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                pabaixo = false;
            }
        }

        private void ReiniciarJogo()
        {
            // Exibe uma mensagem para confirmar o rein�cio, se desejado
            var result = MessageBox.Show("Voc� deseja reiniciar o jogo?", "Options", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                // Volta para a tela do menu
                MostrarMenu();
            }
            else
            {
               MostrarTelaLogin();
            }
        }


        private void IniciarJogo()
        {

            InitializeComponent();
        }


        private void VoltarLogin()
        {

        }

        private void MostrarMenu()
        {
            // Crie uma nova inst�ncia da tela do Menu
            MenuForm menuForm = new MenuForm();

            // Esconde a tela atual (o jogo)
            this.Hide();

            // Adiciona um evento para iniciar o jogo automaticamente ap�s o menu ser exibido
            menuForm.FormClosed += (s, args) => {
                IniciarJogo(); // Chama o m�todo para iniciar o jogo automaticamente
            };

            // Mostra a tela do Menu
            menuForm.Show();
        }




        private void MostrarTelaLogin()
        {
            // Crie uma nova inst�ncia da tela de login
            LoginForm loginForm = new LoginForm();

            // Esconde a tela atual
            this.Hide();

            // Mostra a tela de login
            loginForm.Show();
        }

        private void btn_restart_Click(object sender, EventArgs e)
        {
            ReiniciarJogo(); // Chama o m�todo que reinicia o jogo
        }
    }
}

