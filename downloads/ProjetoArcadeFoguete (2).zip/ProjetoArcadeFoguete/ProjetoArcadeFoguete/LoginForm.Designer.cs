﻿namespace ProjetoArcadeFoguete
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtGamerTagLogin = new TextBox();
            txtSenhaLogin = new TextBox();
            lbl_login = new Label();
            btn_cadastrese = new Button();
            btn_login = new Button();
            btn_exit = new Button();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // txtGamerTagLogin
            // 
            txtGamerTagLogin.BorderStyle = BorderStyle.FixedSingle;
            txtGamerTagLogin.Location = new Point(93, 91);
            txtGamerTagLogin.Name = "txtGamerTagLogin";
            txtGamerTagLogin.Size = new Size(136, 23);
            txtGamerTagLogin.TabIndex = 0;
            // 
            // txtSenhaLogin
            // 
            txtSenhaLogin.BorderStyle = BorderStyle.FixedSingle;
            txtSenhaLogin.Location = new Point(93, 147);
            txtSenhaLogin.Name = "txtSenhaLogin";
            txtSenhaLogin.Size = new Size(136, 23);
            txtSenhaLogin.TabIndex = 1;
            txtSenhaLogin.UseSystemPasswordChar = true;
            // 
            // lbl_login
            // 
            lbl_login.AutoSize = true;
            lbl_login.BackColor = SystemColors.ActiveCaptionText;
            lbl_login.Font = new Font("Space Age", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_login.ForeColor = Color.FromArgb(255, 255, 128);
            lbl_login.Location = new Point(47, 27);
            lbl_login.Name = "lbl_login";
            lbl_login.Size = new Size(229, 17);
            lbl_login.TabIndex = 2;
            lbl_login.Text = "FAÇA SEU LOGIN";
            // 
            // btn_cadastrese
            // 
            btn_cadastrese.BackColor = SystemColors.ActiveCaptionText;
            btn_cadastrese.Font = new Font("Space Age", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_cadastrese.ForeColor = Color.FromArgb(255, 255, 128);
            btn_cadastrese.Location = new Point(186, 248);
            btn_cadastrese.Name = "btn_cadastrese";
            btn_cadastrese.Size = new Size(138, 25);
            btn_cadastrese.TabIndex = 3;
            btn_cadastrese.Text = "Cadastre-se";
            btn_cadastrese.TextAlign = ContentAlignment.MiddleRight;
            btn_cadastrese.UseVisualStyleBackColor = false;
            btn_cadastrese.Click += btn_cadastrese_Click;
            // 
            // btn_login
            // 
            btn_login.BackColor = Color.FromArgb(255, 255, 128);
            btn_login.Font = new Font("Space Age", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_login.Location = new Point(114, 196);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(85, 27);
            btn_login.TabIndex = 4;
            btn_login.Text = "Entrar";
            btn_login.UseVisualStyleBackColor = false;
            btn_login.Click += btn_login_Click;
            // 
            // btn_exit
            // 
            btn_exit.BackColor = SystemColors.ActiveCaptionText;
            btn_exit.Font = new Font("Space Age", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_exit.ForeColor = Color.FromArgb(255, 255, 128);
            btn_exit.Location = new Point(269, -2);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(55, 26);
            btn_exit.TabIndex = 5;
            btn_exit.Text = "Sair";
            btn_exit.UseVisualStyleBackColor = false;
            btn_exit.Click += btn_exit_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.starsback;
            pictureBox2.Location = new Point(-11, -2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(335, 275);
            pictureBox2.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox2.TabIndex = 8;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaptionText;
            label1.Font = new Font("Space Age", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(255, 255, 128);
            label1.Location = new Point(93, 77);
            label1.Name = "label1";
            label1.Size = new Size(57, 11);
            label1.TabIndex = 9;
            label1.Text = "nome:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ActiveCaptionText;
            label2.Font = new Font("Space Age", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(255, 255, 128);
            label2.Location = new Point(93, 133);
            label2.Name = "label2";
            label2.Size = new Size(68, 11);
            label2.TabIndex = 10;
            label2.Text = "SENHA:";
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(320, 272);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btn_exit);
            Controls.Add(btn_login);
            Controls.Add(btn_cadastrese);
            Controls.Add(lbl_login);
            Controls.Add(txtSenhaLogin);
            Controls.Add(txtGamerTagLogin);
            Controls.Add(pictureBox2);
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LoginForm";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtGamerTagLogin;
        private TextBox txtSenhaLogin;
        private Label lbl_login;
        private Button btn_cadastrese;
        private Button btn_login;
        private Button btn_exit;
        private PictureBox pictureBox2;
        private Label label1;
        private Label label2;
    }
}